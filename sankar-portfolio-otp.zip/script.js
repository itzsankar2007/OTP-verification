const otpForm = document.getElementById("otpForm");
const otpInput = document.getElementById("otpInput");
const otpMessage = document.getElementById("otpMessage");
const contactDetails = document.getElementById("contactDetails");
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

// Keep the demo OTP to four numeric digits.
otpInput.addEventListener("input", () => {
  otpInput.value = otpInput.value.replace(/\\D/g, "").slice(0, 4);
  otpMessage.textContent = "";
  otpMessage.className = "otp-message";
  contactDetails.hidden = true;
});

otpForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (otpInput.value === "1234") {
    otpMessage.textContent = "Verified successfully!";
    otpMessage.className = "otp-message success";
    contactDetails.hidden = false;
  } else {
    otpMessage.textContent = "Wrong OTP! Please try again.";
    otpMessage.className = "otp-message error";
    contactDetails.hidden = true;
  }
});

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();
