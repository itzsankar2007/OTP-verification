SANKAR PORTFOLIO WEBSITE WITH OTP VERIFICATION

Files included:
- index.html  : portfolio page structure
- style.css   : responsive website design
- script.js   : OTP check and mobile navigation

HOW TO OPEN:
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open index.html in your browser, or use the Live Server extension.
4. Scroll to Contact Me.
5. Enter demo OTP 1234 and click Verify OTP.
6. Any other value displays Wrong OTP.

CUSTOMIZE:
- Edit "Sankar" and the About Me text in index.html.
- Update the sample project descriptions and skills.
- Replace yourname@example.com and the phone placeholder with your own contact details.

IMPORTANT:
This is a frontend demonstration. The demo OTP is hardcoded as 1234 in script.js.
Do not use this client-side check for real account security or real OTP authentication.
